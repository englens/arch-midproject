var searchData=
[
  ['playername_125',['PlayerName',['../class_player_u_i.html#ac0ab14df55b63d34857f2590fccea504',1,'PlayerUI']]]
];
