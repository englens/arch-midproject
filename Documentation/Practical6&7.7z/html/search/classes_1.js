var searchData=
[
  ['core_77',['Core',['../class_core.html',1,'']]]
];
