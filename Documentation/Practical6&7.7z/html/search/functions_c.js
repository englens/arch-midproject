var searchData=
[
  ['_7egameobserver_134',['~GameObserver',['../class_game_observer.html#ad8e1ebc2c4b7a0017a2ffaec964a7bcd',1,'GameObserver']]]
];
