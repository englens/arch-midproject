var searchData=
[
  ['ui_5fapi_66',['UI_API',['../_player_u_i_8h.html#a361475d108979212e1cdef3eec471d34',1,'PlayerUI.h']]],
  ['update_67',['Update',['../class_game_observer.html#a9ccd8b6906514ac9b60fcb16c91d148b',1,'GameObserver']]]
];
