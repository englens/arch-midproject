var searchData=
[
  ['damage_5fapi_147',['DAMAGE_API',['../_damage_8h.html#a3a0f92cd2beb86ba9dc20f61be2351cc',1,'Damage.h']]]
];
