var searchData=
[
  ['difficulty_138',['Difficulty',['../class_a_i_builder.html#a7329f1eb1bc8b06a74c900f3c80475b2',1,'AIBuilder']]]
];
