var searchData=
[
  ['update_132',['Update',['../class_game_observer.html#a9ccd8b6906514ac9b60fcb16c91d148b',1,'GameObserver']]]
];
