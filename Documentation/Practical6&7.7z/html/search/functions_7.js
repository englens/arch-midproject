var searchData=
[
  ['notify_124',['Notify',['../class_game.html#a8aa3b832eed63a2178fa12e590a08eff',1,'Game']]]
];
