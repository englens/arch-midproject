var searchData=
[
  ['core_5fapi_146',['CORE_API',['../_core_8h.html#afea66f9a6812c2354b544f31910fd72f',1,'Core.h']]]
];
